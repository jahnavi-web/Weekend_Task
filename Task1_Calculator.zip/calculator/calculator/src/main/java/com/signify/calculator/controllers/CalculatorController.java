package com.signify.calculator.controllers;

import com.signify.calculator.models.CalculationRequest;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/calculator")  // Base path for all endpoints
public class CalculatorController {

    // Home page
    @GetMapping("/")
    public String home() {
        return "Welcome to the Calculator API! Use /add, /subtract, /multiply, /divide";
    }

    // Addition API
    @PostMapping("/add")
    public String add(@RequestBody CalculationRequest request) {
        double result = request.getNum1() + request.getNum2();
        return "Addition result: " + result;
    }

    // Subtraction API
    @PostMapping("/subtract")
    public String subtract(@RequestBody CalculationRequest request) {
        double result = request.getNum1() - request.getNum2();
        return "Subtraction result: " + result;
    }

    // Multiplication API
    @PostMapping("/multiply")
    public String multiply(@RequestBody CalculationRequest request) {
        double result = request.getNum1() * request.getNum2();
        return "Multiplication result: " + result;
    }

    // Division API (handles division by zero)
    @PostMapping("/divide")
    public String divide(@RequestBody CalculationRequest request) {
        if (request.getNum2() == 0) {
            return "Error: Division by zero is not allowed!";
        }
        double result = request.getNum1() / request.getNum2();
        return "Division result: " + result;
    }
}
