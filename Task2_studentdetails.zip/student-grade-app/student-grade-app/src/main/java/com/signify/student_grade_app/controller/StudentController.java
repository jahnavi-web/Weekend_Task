package com.signify.student_grade_app.controller;

import com.signify.student_grade_app.model.StudentDetails;
import com.signify.student_grade_app.model.SubjectMarks;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {

    @GetMapping("/")
    public String homePage() {
        return "Welcome to the Student Grade Generator Application! \n"
                + "Available APIs: \n"
                + "1. POST /student/studentEntry - Add student details \n"
                + "2. POST /student/findResult - Calculate student grade";
    }


    @PostMapping("/studentEntry")
    public String studentEntry(@RequestBody StudentDetails student) {
        return "Student " + student.getName() + " (Roll No: " + student.getRollNumber() + ") added successfully.";
    }

    @PostMapping("/findResult")
    public String findResult(@RequestBody List<SubjectMarks> subjects) {
        double totalMarksObtained = 0;
        double totalMaxMarks = 0;

        for (SubjectMarks subject : subjects) {
            totalMarksObtained += subject.getMarksObtained();
            totalMaxMarks += subject.getMaxMarks();
        }

        double percentage = (totalMarksObtained / totalMaxMarks) * 100;
        String grade = calculateGrade(percentage);

        return "Total Percentage: " + percentage + "% | Grade: " + grade + (grade.equals("F") ? " (Failed)" : " (Passed)");
    }

    private String calculateGrade(double percentage) {
        if (percentage >= 90) return "S";
        else if (percentage >= 85) return "A+";
        else if (percentage >= 80) return "A";
        else if (percentage >= 75) return "B+";
        else if (percentage >= 70) return "B";
        else if (percentage >= 65) return "C+";
        else if (percentage >= 60) return "C";
        else if (percentage >= 55) return "D+";
        else if (percentage >= 50) return "D";
        else return "F";
    }
}
